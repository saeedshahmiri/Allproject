import json
import requests
import boto3
from datetime import datetime

def lambda_handler(event, context):
    
    # Define the API endpoint URL
    url = "https://jsonplaceholder.typicode.com/users"
    
    # Send a GET request to the API
    response = requests.get(url)
    
    # Parse the JSON data from the response
    data = response.json()
    
    cilent = boto3.client('s3')

    
    filename = "mypro_raw_" + str(datetime.now()) + ".json"
    
    cilent.put_object(
        Bucket="1710training",
        Key="rawdata/toprocess/" + filename,
        Body=json.dumps(data)
        )
    
    return data